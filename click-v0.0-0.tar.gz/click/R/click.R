onMouse <- function(buttons, x, y) {
    Buttons <- rep(F, 3)
    for (k in buttons) Buttons[1 + k] <- T
    list(BUTTONS=Buttons, COORDS=c(x, y)) }

onMouseDown <- function(...)
        c(onMouse(...), RELEASE=F)

onMouseUp <- function(...)
        c(onMouse(...), RELEASE=T)

makeGraphicsEventHandlersStd <- function(
        prompt="Waiting for input",
        onIdle=NULL,
        consolePrompt=prompt ) {
    ENV.SAVED <- getGraphicsEventEnv()
    

    R <- list()

    #FUTURE
    #fnset(onMouseDown=onMouseDown);   R <- c(R, MOUSEDOWN  =fnget())
    #fnset(onMouseUp  =onMouseUp);     R <- c(R, MOUSEUP    =fnget())

    setGraphicsEventHandlers(
        prompt=prompt,
        onMouseDown=onMouseDown,
        onMouseUp  =onMouseUp,
        onIdle=onIdle,
        consolePrompt=consolePrompt)
    
    R <- c(R, MOUSEDOWNUP=getGraphicsEventEnv())

    setGraphicsEventEnv(env=ENV.SAVED)

    R }

getGraphicsEventMouse <- function(env, which=dev.cur(), table=matrix(rep(NA, 4)), quiet=T, xyonly=F) {
    entryreport <- function() if (!quiet) {
        cat("\ngetGraphicsEventMouse:---\n")
        flush.console() }
    report <- function() if (!quiet) {
        cat("Response:---\n")
        print(Response)
        cat("---(END Response).\n")
        cat("Response Summary:---\n")
        print(Diff)
        cat("---(END Response Summary).\n")
        cat("table:---\n")
        print(table)
        cat("---(END table).\n")
        flush.console() }
    exitreport <- function() if (!quiet) {
        cat("---(END getGraphicsEventMouse).\n\n")
        flush.console() }
    if (!quiet) dimnames(table) <- list(c("ZERO", "ONE", "TWO", "RELEASE"), NULL)
    entryreport()
    setGraphicsEventEnv(which=which, env=env)
    repeat {
        Continue <- T
        Response <- getGraphicsEvent()
        Diff <- xor(table, unlist(Response[c("BUTTONS", "RELEASE")]))
        Diff[is.na(Diff)] <- F # I.E., NO DIFFERENCE
        report()
        for (k in seq(ncol(Diff))) {
                if (!any(Diff[,k])) {
                    Continue <- F
                    break } }
        if (!Continue) break
    }
    exitreport()
    if (xyonly) Response$COORDS else Response }


getGraphicsEventMouseClickAndDrag <- function(env) {
    E1 <- getGraphicsEventMouse(env=env, table=matrix(c(T,F,F,F)), xyonly=T)
    E2 <- getGraphicsEventMouse(env=env, table=matrix(c(F,F,F,T)), xyonly=T)
    XY <- do.call(cbind, list(E1, E2))
    dimnames(XY) <- list(c("X", "Y"), NULL)
    XY }
